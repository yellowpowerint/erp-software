M7.2 iOS Submission Package (template)
