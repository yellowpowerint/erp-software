M7.3 Android Play Store Submission Package (template)
